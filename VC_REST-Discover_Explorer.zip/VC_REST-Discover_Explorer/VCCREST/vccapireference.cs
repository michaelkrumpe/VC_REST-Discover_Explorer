﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace VC_REST_Discover_Explorer.VCCREST
{
    public class vccapireference
    {
    }
}