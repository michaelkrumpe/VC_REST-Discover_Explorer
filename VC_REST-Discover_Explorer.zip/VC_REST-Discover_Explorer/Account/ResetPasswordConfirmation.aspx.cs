﻿using System.Web.UI;

namespace VC_REST_Discover_Explorer.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}